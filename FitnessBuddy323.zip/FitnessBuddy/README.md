# Fitness Buddy Chat (ITAS1 Final Project)

A Java LAN group-chat application for students who want to coordinate workouts.
Built with Java `Socket` / `ServerSocket`, a thread per client, and a Swing GUI.

## 1. Members and Course
| Name | GitHub username | Role |
|------|-----------------|------|
| _Student 1_ | _@username1_ | _e.g. Server + protocol_ |
| _Student 2_ | _@username2_ | _e.g. Client GUI + testing_ |

- Course / Section: _ITAS1 – Network Programming, Section ____
- Instructor: _______

## 2. Concept Proposal
- **Theme:** Fitness Buddy
- **Target users:** Students coordinating exercise.
- **User problem:** Workout plans get lost in ordinary chat. Nobody knows who is actually coming, so sessions get cancelled or people show up alone.
- **Original feature 1 – Workout Session Proposals:** any user proposes a workout (activity, time, place). The proposal appears in every client's "Workout Sessions" panel. The host can cancel it.
- **Original feature 2 – Attendance Confirmations:** users press **I'm Going** or **Can't Make It**. Every client sees the live Going / Can't lists update. Attendance is removed automatically if a user disconnects, and names update on `/name`.
- **Sample screens:** see Section 8.
- **Instructor approval:** _Approved by ________ on ________ (record here)_

## 3. Core Features
- Server + 3 or more concurrent clients (thread per client, cached thread pool)
- Server IP and port entered by the user
- Swing GUI: connection controls, nickname field, message box, Send button, chat area, online list
- Group broadcast (once to every client including the sender) with sender nickname and time
- Unique, non-blank nicknames; `/name`, `/exit`, `/help`
- Blank-message rejection, IP/port validation, friendly errors, clean socket release
- Networking runs off the GUI thread; all Swing updates happen on the Event Dispatch Thread

## 4. Architecture

```
 +-----------------+        TCP (text lines)        +-------------------------+
 | FitnessClient 1 | <----------------------------> |                         |
 +-----------------+                                |      FitnessServer      |
 +-----------------+        TCP (text lines)        |  - ServerSocket :5000   |
 | FitnessClient 2 | <----------------------------> |  - Handler thread/client|
 +-----------------+                                |  - Shared state + lock  |
 +-----------------+        TCP (text lines)        |    (clients, sessions)  |
 | FitnessClient 3 | <----------------------------> |                         |
 +-----------------+                                +-------------------------+

 Message path: client GUI -> sender thread -> socket -> server Handler (validate)
               -> broadcast() to every Handler.send() -> client reader thread
               -> SwingUtilities.invokeLater -> chat area
```

Concurrency: every change to shared state happens inside `synchronized (lock)`. `Handler.send()` is synchronized so two threads cannot interleave lines to the same client.

### Message format (one UTF-8 line per message, fields separated by `|`)
| Direction | Message | Meaning |
|-----------|---------|---------|
| C → S | `HELLO\|nick` | Join with nickname |
| C → S | `CHAT\|text` | Chat text or a command (`/name x`, `/exit`, `/help`) |
| C → S | `PROPOSE\|activity\|when\|where` | New workout session |
| C → S | `RSVP\|id\|GOING` or `RSVP\|id\|NOTGOING` | Attendance |
| C → S | `CANCEL\|id` | Host cancels session |
| S → C | `NICKOK\|nick` / `NICKERR\|reason` | Nickname accepted / rejected |
| S → C | `MSG\|HH:mm\|sender\|text` | Chat broadcast |
| S → C | `SYS\|HH:mm\|text` | Server notice (join, leave, rename, errors) |
| S → C | `USERS\|a,b,c` | Online list |
| S → C | `SESSION\|id\|host\|activity\|when\|where\|going;..\|declined;..` | Create/update session |
| S → C | `SESSIONDEL\|id` | Session removed |
| S → C | `BYE\|` | Acknowledge `/exit` |

## 5. Setup
- **Java:** JDK 11 or newer (`java -version`)
- **Dependencies:** none (standard library only)
- **IDE / build tool:** any IDE, or the command line:

```bash
cd FitnessBuddy
mkdir out
javac -d out src/*.java
```

**Run the app** (every player, on any computer on the same Wi-Fi/LAN):
```bash
java -cp out FitnessClient
```
The first screen has two options:
- **Host a Room** – enter a nickname and port (default 5000). The server starts inside the app and the room screen shows the IP address friends must use.
- **Join a Room** – enter a nickname, the host's IP address and the port, then **Join Room**. Use `localhost` if the host is on the same computer.

(Optional) A standalone console server is also available: `java -cp out FitnessServer 5000`.

**Troubleshooting**
- *Cannot reach the server:* check the IP, the port, and that both computers are on the same network.
- *Still blocked:* allow Java through the firewall on the server computer (or allow TCP port 5000).
- *Port in use:* start the server with another port, e.g. `java -cp out FitnessServer 6000`.

## 6. Commands
| Command | Effect |
|---------|--------|
| `/name <newname>` | Change nickname (validated, updates everyone) |
| `/exit` | Leave the chat cleanly |
| `/help` | Show the command list |

## 7. Test Results (fill in Actual / Status after running)
| # | Test | Steps | Expected | Actual | Status |
|---|------|-------|----------|--------|--------|
| 1 | Three concurrent clients | Connect 3 clients | All appear in online list | | |
| 2 | Broadcast | Client A sends text | A, B, C each see it once with nickname + time | | |
| 3 | Online list updates | Client joins/leaves | All lists update | | |
| 4 | Valid nickname change | `/name Mia` | Everyone sees rename; list updates | | |
| 5 | Duplicate nickname | Join/rename to a name in use | Rejected with message | | |
| 6 | Blank message | Press Send with empty box | Not sent | | |
| 7 | Invalid IP / port | Enter `abc` / `99999` | Error dialog, GUI responsive | | |
| 8 | Unavailable server | Connect with server off | "Cannot reach the server" dialog | | |
| 9 | Clean `/exit` | Type `/exit` | Client disconnects, others see "left" | | |
| 10 | Abrupt disconnect | Kill a client process | Server and others keep working | | |
| 11 | Chat continues | After #10, remaining clients chat | Messages still delivered | | |
| 12 | Feature 1 sync | Client A proposes workout | Appears on A, B, C | | |
| 13 | Feature 2 sync | B clicks I'm Going; C clicks Can't Make It | All clients show updated lists | | |
| 14 | Host-only cancel | Non-host clicks Cancel | Rejected; host cancel removes it everywhere | | |
| 15 | Two computers | Server on PC1, clients on PC1 + PC2 | Works over LAN | | |

## 8. Screenshots
_Add labeled screenshots in `/screenshots` and link them here (connection, group chat, propose workout, attendance, error case)._

## 9. Contribution Log
| Date | Member | Task | Commit link |
|------|--------|------|-------------|
| | | | |

## 10. Credits and AI Assistance
- Built with the Java standard library (`java.net`, `javax.swing`).
- AI assistance: initial code scaffold was generated with Claude (Anthropic). Both members reviewed, tested and can explain the code.
