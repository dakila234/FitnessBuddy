import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Fitness Buddy (Swing).
 * Screens: MENU (Host / Join) -> HOST form or JOIN form -> CHAT room.
 * - "Host a Room" starts the server inside this app, then connects to it.
 * - "Join a Room" connects to a host on the LAN by IP + port.
 * Networking runs off the GUI thread; Swing is only touched on the EDT.
 */
public class FitnessClient extends JFrame {
    private static final Color GREEN = new Color(34, 139, 84);
    private static final Color DARK = new Color(20, 90, 55);
    private static final Color LIGHT = new Color(240, 248, 243);

    private final CardLayout cards = new CardLayout();
    private final JPanel root = new JPanel(cards);

    // host form
    private final JTextField hostNick = new JTextField(16);
    private final JTextField hostPort = new JTextField("5000", 16);
    private final JButton startHostBtn = new JButton("Start Hosting");
    // join form
    private final JTextField joinNick = new JTextField(16);
    private final JTextField joinIp = new JTextField("localhost", 16);
    private final JTextField joinPort = new JTextField("5000", 16);
    private final JButton joinBtn = new JButton("Join Room");

    // chat screen
    private final JLabel roomLabel = new JLabel(" ");
    private final JButton leaveBtn = new JButton("Leave Room");
    private final JTextArea chatArea = new JTextArea();
    private final JTextField input = new JTextField();
    private final JButton sendBtn = new JButton("Send");
    private final DefaultListModel<String> usersModel = new DefaultListModel<>();
    private final JPanel usersPanel = new JPanel(new BorderLayout());
    private final DefaultListModel<Workout> workoutModel = new DefaultListModel<>();
    private final JList<Workout> workoutList = new JList<>(workoutModel);

    private final ExecutorService sender = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "sender");
        t.setDaemon(true);
        return t;
    });

    private volatile Socket socket;
    private volatile PrintWriter out;
    private volatile boolean connected = false;
    private volatile boolean intentionalClose = false;
    private volatile FitnessServer server; // non-null only when hosting
    private String myName = "";

    /** Client-side copy of a workout session. */
    static class Workout {
        int id;
        String host, activity, when, where, going, declined;

        private static String esc(String s) {
            return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
        }

        @Override
        public String toString() {
            int g = going.isEmpty() ? 0 : going.split(";").length;
            int d = declined.isEmpty() ? 0 : declined.split(";").length;
            return "<html><div style='width:230px'><b>#" + id + " " + esc(activity) + "</b><br>"
                    + esc(when) + " @ " + esc(where) + "<br>"
                    + "Host: " + esc(host) + "<br>"
                    + "<font color='#228B54'>Going (" + g + "): " + esc(going.replace(";", ", ")) + "</font><br>"
                    + "<font color='#B22222'>Can't (" + d + "): " + esc(declined.replace(";", ", ")) + "</font>"
                    + "</div></html>";
        }
    }

    public FitnessClient() {
        super("Fitness Buddy");
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override public void windowClosing(java.awt.event.WindowEvent e) { shutdown(); }
        });
        root.add(buildMenu(), "menu");
        root.add(buildForm("Host a Room",
                "Start a room on this computer. Friends on your Wi-Fi/LAN join using your IP.",
                new String[]{"Your nickname:", "Port:"}, new JComponent[]{hostNick, hostPort},
                startHostBtn), "host");
        root.add(buildForm("Join a Room",
                "Enter the IP address and port shown by the host.",
                new String[]{"Your nickname:", "Host IP address:", "Port:"},
                new JComponent[]{joinNick, joinIp, joinPort}, joinBtn), "join");
        root.add(buildChat(), "chat");
        add(root);

        startHostBtn.addActionListener(e -> hostRoom());
        joinBtn.addActionListener(e -> joinRoom());

        cards.show(root, "menu");
        setSize(920, 620);
        setLocationRelativeTo(null);
    }

    // ================================================================ screens
    private JButton bigButton(String title, String sub) {
        JButton b = new JButton("<html><center><span style='font-size:16px'><b>" + title
                + "</b></span><br><span style='font-size:10px'>" + sub + "</span></center></html>");
        b.setAlignmentX(Component.CENTER_ALIGNMENT);
        Dimension d = new Dimension(340, 74);
        b.setPreferredSize(d);
        b.setMaximumSize(d);
        b.setBackground(Color.WHITE);
        b.setForeground(DARK);
        b.setFocusPainted(false);
        return b;
    }

    private JPanel buildMenu() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(GREEN);
        JPanel box = new JPanel();
        box.setLayout(new BoxLayout(box, BoxLayout.Y_AXIS));
        box.setOpaque(false);

        JLabel title = new JLabel("Fitness Buddy");
        title.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 42));
        title.setForeground(Color.WHITE);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel sub = new JLabel("Plan workouts. Confirm who's coming. Stay on track.");
        sub.setForeground(new Color(220, 245, 230));
        sub.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
        sub.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton host = bigButton("HOST A ROOM", "Start a room on this computer");
        JButton join = bigButton("JOIN A ROOM", "Connect to a friend's room");
        host.addActionListener(e -> cards.show(root, "host"));
        join.addActionListener(e -> cards.show(root, "join"));

        box.add(title);
        box.add(Box.createVerticalStrut(6));
        box.add(sub);
        box.add(Box.createVerticalStrut(36));
        box.add(host);
        box.add(Box.createVerticalStrut(14));
        box.add(join);
        p.add(box);
        return p;
    }

    private JPanel buildForm(String heading, String hint, String[] labels, JComponent[] fields, JButton primary) {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(LIGHT);
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(6, 6, 6, 6);
        c.gridx = 0;
        c.gridy = 0;
        c.gridwidth = 2;

        JLabel h = new JLabel(heading);
        h.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 28));
        h.setForeground(DARK);
        p.add(h, c);
        c.gridy++;
        JLabel hl = new JLabel("<html><div style='width:320px;color:#555'>" + hint + "</div></html>");
        p.add(hl, c);

        c.gridwidth = 1;
        c.anchor = GridBagConstraints.WEST;
        for (int i = 0; i < labels.length; i++) {
            c.gridy++;
            c.gridx = 0;
            p.add(new JLabel(labels[i]), c);
            c.gridx = 1;
            p.add(fields[i], c);
        }

        primary.setBackground(GREEN);
        primary.setForeground(Color.WHITE);
        primary.setFocusPainted(false);
        primary.setPreferredSize(new Dimension(150, 36));
        JButton back = new JButton("Back");
        back.setPreferredSize(new Dimension(90, 36));
        back.addActionListener(e -> cards.show(root, "menu"));
        JPanel row = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        row.setOpaque(false);
        row.add(back);
        row.add(primary);
        c.gridy++;
        c.gridx = 0;
        c.gridwidth = 2;
        c.anchor = GridBagConstraints.CENTER;
        c.insets = new Insets(20, 6, 6, 6);
        p.add(row, c);
        return p;
    }

    private JPanel buildChat() {
        // header
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(GREEN);
        header.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
        JLabel appName = new JLabel("Fitness Buddy");
        appName.setForeground(Color.WHITE);
        appName.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        roomLabel.setForeground(new Color(220, 245, 230));
        JPanel left = new JPanel(new GridLayout(2, 1));
        left.setOpaque(false);
        left.add(appName);
        left.add(roomLabel);
        header.add(left, BorderLayout.WEST);
        header.add(leaveBtn, BorderLayout.EAST);
        leaveBtn.addActionListener(e -> leaveRoom());

        // chat
        chatArea.setEditable(false);
        chatArea.setLineWrap(true);
        chatArea.setWrapStyleWord(true);
        chatArea.setMargin(new Insets(6, 6, 6, 6));
        JPanel inputRow = new JPanel(new BorderLayout(6, 0));
        inputRow.add(input, BorderLayout.CENTER);
        inputRow.add(sendBtn, BorderLayout.EAST);
        JPanel center = new JPanel(new BorderLayout(0, 6));
        center.setBorder(BorderFactory.createTitledBorder("Group Chat"));
        center.add(new JScrollPane(chatArea), BorderLayout.CENTER);
        center.add(inputRow, BorderLayout.SOUTH);
        sendBtn.addActionListener(e -> sendChat());
        input.addActionListener(e -> sendChat());

        // online list
        JList<String> usersList = new JList<>(usersModel);
        usersPanel.setBorder(BorderFactory.createTitledBorder("Online (0)"));
        usersPanel.add(new JScrollPane(usersList), BorderLayout.CENTER);

        // workouts
        JPanel workoutPanel = new JPanel(new BorderLayout(0, 6));
        workoutPanel.setBorder(BorderFactory.createTitledBorder("Workout Sessions"));
        workoutList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        workoutPanel.add(new JScrollPane(workoutList), BorderLayout.CENTER);
        JButton proposeBtn = new JButton("Propose Workout");
        JButton goingBtn = new JButton("I'm Going");
        JButton cantBtn = new JButton("Can't Make It");
        JButton cancelBtn = new JButton("Cancel (host)");
        JPanel btns = new JPanel(new GridLayout(2, 2, 4, 4));
        btns.add(proposeBtn);
        btns.add(cancelBtn);
        btns.add(goingBtn);
        btns.add(cantBtn);
        workoutPanel.add(btns, BorderLayout.SOUTH);
        proposeBtn.addActionListener(e -> proposeDialog());
        goingBtn.addActionListener(e -> rsvp("GOING"));
        cantBtn.addActionListener(e -> rsvp("NOTGOING"));
        cancelBtn.addActionListener(e -> {
            Workout w = workoutList.getSelectedValue();
            if (w == null) { info("Select a workout session first."); return; }
            send("CANCEL|" + w.id);
        });

        JPanel east = new JPanel(new GridLayout(2, 1, 0, 6));
        east.setPreferredSize(new Dimension(300, 0));
        east.add(usersPanel);
        east.add(workoutPanel);

        JPanel body = new JPanel(new BorderLayout(6, 6));
        body.setBorder(BorderFactory.createEmptyBorder(6, 6, 6, 6));
        body.add(center, BorderLayout.CENTER);
        body.add(east, BorderLayout.EAST);

        JPanel p = new JPanel(new BorderLayout());
        p.add(header, BorderLayout.NORTH);
        p.add(body, BorderLayout.CENTER);
        return p;
    }

    private void info(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Fitness Buddy", JOptionPane.INFORMATION_MESSAGE);
    }

    private void append(String line) {
        chatArea.append(line + "\n");
        chatArea.setCaretPosition(chatArea.getDocument().getLength());
    }

    private void setBusy(boolean busy) {
        startHostBtn.setEnabled(!busy);
        joinBtn.setEnabled(!busy);
        startHostBtn.setText(busy ? "Starting..." : "Start Hosting");
        joinBtn.setText(busy ? "Connecting..." : "Join Room");
    }

    // ======================================================== host / join
    private static final String NICK_RULE = "Nickname must be 1-15 letters, numbers, _ or - (no spaces).";

    private Integer parsePort(String text) {
        try {
            int p = Integer.parseInt(text.trim());
            if (p < 1 || p > 65535) throw new NumberFormatException();
            return p;
        } catch (NumberFormatException e) {
            info("Invalid port. Enter a number from 1 to 65535.");
            return null;
        }
    }

    private void hostRoom() {
        final String nick = hostNick.getText().trim();
        if (nick.isEmpty()) { info("Please enter a nickname."); return; }
        if (!nick.matches("[A-Za-z0-9_\\-]{1,15}")) { info(NICK_RULE); return; }
        final Integer port = parsePort(hostPort.getText());
        if (port == null) return;

        setBusy(true);
        new Thread(() -> {
            FitnessServer srv = new FitnessServer();
            try {
                srv.startAsync(port);
            } catch (IOException e) {
                SwingUtilities.invokeLater(() -> {
                    setBusy(false);
                    info("Cannot start the room on port " + port + ".\nIs another program (or another room) using it?\n" + e.getMessage());
                });
                return;
            }
            server = srv;
            java.util.List<String> ips = FitnessServer.localIps();
            String shown = ips.isEmpty() ? "this computer's IP" : String.join(" / ", ips);
            connectBlocking("localhost", port, nick, "Hosting - friends join at " + shown + "   port " + port);
        }, "host").start();
    }

    private void joinRoom() {
        final String nick = joinNick.getText().trim();
        final String ip = joinIp.getText().trim();
        if (nick.isEmpty()) { info("Please enter a nickname."); return; }
        if (!nick.matches("[A-Za-z0-9_\\-]{1,15}")) { info(NICK_RULE); return; }
        if (ip.isEmpty()) { info("Please enter the host's IP address."); return; }
        final Integer port = parsePort(joinPort.getText());
        if (port == null) return;

        setBusy(true);
        new Thread(() -> connectBlocking(ip, port, nick, "Joined room at " + ip + " : " + port), "join").start();
    }

    private void stopServerIfHosting() {
        FitnessServer s = server;
        server = null;
        if (s != null) s.stop();
    }

    /** Runs on a background thread. Connects, then blocks reading until disconnected. */
    private void connectBlocking(String host, int port, String nick, String roomInfo) {
        try {
            Socket s = new Socket();
            s.connect(new InetSocketAddress(host, port), 4000);
            BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
            PrintWriter pw = new PrintWriter(new OutputStreamWriter(s.getOutputStream(), StandardCharsets.UTF_8), true);
            pw.println("HELLO|" + nick);
            s.setSoTimeout(5000);
            String resp = in.readLine();
            s.setSoTimeout(0);
            if (resp == null) throw new IOException("The host closed the connection.");
            if (resp.startsWith("NICKERR|")) {
                s.close();
                stopServerIfHosting();
                final String reason = resp.substring(8);
                SwingUtilities.invokeLater(() -> { setBusy(false); info(reason); });
                return;
            }
            if (!resp.startsWith("NICKOK|")) throw new IOException("Unexpected reply from server.");
            final String accepted = resp.substring(7);
            socket = s;
            out = pw;
            intentionalClose = false;
            connected = true;
            SwingUtilities.invokeLater(() -> {
                myName = accepted;
                setBusy(false);
                chatArea.setText("");
                usersModel.clear();
                workoutModel.clear();
                roomLabel.setText(roomInfo + "   |   You: " + myName);
                leaveBtn.setText(server != null ? "Close Room" : "Leave Room");
                append("--- Welcome, " + myName + "! Type /help for commands. ---");
                cards.show(root, "chat");
                input.requestFocusInWindow();
            });
            readLoop(in);
        } catch (Exception e) {
            stopServerIfHosting();
            final String why = (e instanceof SocketTimeoutException)
                    ? "Connection timed out. Check the IP and port."
                    : (e instanceof ConnectException)
                    ? "Cannot reach a room at " + host + ":" + port + ". Is the host running?"
                    : (e instanceof UnknownHostException || e instanceof java.nio.channels.UnresolvedAddressException)
                    ? "Unknown host '" + host + "'. Check the IP address."
                    : "Connection failed: " + e.getMessage();
            SwingUtilities.invokeLater(() -> { setBusy(false); info(why); });
        }
    }

    private void readLoop(BufferedReader in) {
        try {
            String line;
            while ((line = in.readLine()) != null) {
                final String l = line;
                SwingUtilities.invokeLater(() -> handle(l));
            }
        } catch (IOException ignored) {
            // connection lost
        } finally {
            SwingUtilities.invokeLater(() -> onDisconnected(intentionalClose));
        }
    }

    private void send(String line) {
        final PrintWriter pw = out;
        if (pw == null) return;
        sender.execute(() -> pw.println(line));
    }

    private void leaveRoom() {
        if (server != null) {
            int r = JOptionPane.showConfirmDialog(this,
                    "You are the host. Closing the room disconnects everyone. Close it?",
                    "Close Room", JOptionPane.YES_NO_OPTION);
            if (r != JOptionPane.YES_OPTION) return;
        }
        intentionalClose = true;
        send("CHAT|/exit");
        new javax.swing.Timer(800, e -> closeSocket()) {{ setRepeats(false); }}.start();
    }

    private void closeSocket() {
        try { if (socket != null) socket.close(); } catch (IOException ignored) { }
    }

    private void shutdown() {
        intentionalClose = true;
        if (connected) send("CHAT|/exit");
        javax.swing.Timer t = new javax.swing.Timer(300, e -> {
            closeSocket();
            stopServerIfHosting();
            dispose();
            System.exit(0);
        });
        t.setRepeats(false);
        t.start();
    }

    private void onDisconnected(boolean intentional) {
        if (!connected) return;
        connected = false;
        out = null;
        closeSocket();
        stopServerIfHosting();
        usersModel.clear();
        workoutModel.clear();
        usersPanel.setBorder(BorderFactory.createTitledBorder("Online (0)"));
        setBusy(false);
        cards.show(root, "menu");
        if (!intentional) info("The connection to the room was lost.");
    }

    // ===================================================== incoming messages
    private void handle(String line) {
        int i = line.indexOf('|');
        String cmd = i < 0 ? line : line.substring(0, i);
        String rest = i < 0 ? "" : line.substring(i + 1);
        switch (cmd) {
            case "MSG": {
                String[] p = rest.split("\\|", 3);
                if (p.length == 3) append("[" + p[0] + "] " + p[1] + ": " + p[2]);
                break;
            }
            case "SYS": {
                String[] p = rest.split("\\|", 2);
                if (p.length == 2) append("[" + p[0] + "] * " + p[1]);
                break;
            }
            case "USERS": {
                usersModel.clear();
                int n = 0;
                if (!rest.isEmpty()) for (String u : rest.split(",")) { usersModel.addElement(u); n++; }
                usersPanel.setBorder(BorderFactory.createTitledBorder("Online (" + n + ")"));
                usersPanel.repaint();
                break;
            }
            case "NICKOK":
                myName = rest;
                String info = roomLabel.getText();
                int bar = info.lastIndexOf("   |   You: ");
                if (bar >= 0) roomLabel.setText(info.substring(0, bar) + "   |   You: " + myName);
                break;
            case "SESSION":
                upsertWorkout(rest);
                break;
            case "SESSIONDEL": {
                try {
                    int id = Integer.parseInt(rest.trim());
                    for (int k = 0; k < workoutModel.size(); k++)
                        if (workoutModel.get(k).id == id) { workoutModel.remove(k); break; }
                } catch (NumberFormatException ignored) { }
                break;
            }
            case "BYE":
                intentionalClose = true;
                closeSocket();
                break;
            default:
                break;
        }
    }

    private void upsertWorkout(String data) {
        String[] p = data.split("\\|", -1);
        if (p.length < 7) return;
        Workout w = new Workout();
        try { w.id = Integer.parseInt(p[0]); } catch (NumberFormatException e) { return; }
        w.host = p[1]; w.activity = p[2]; w.when = p[3]; w.where = p[4]; w.going = p[5]; w.declined = p[6];
        for (int k = 0; k < workoutModel.size(); k++) {
            if (workoutModel.get(k).id == w.id) { workoutModel.set(k, w); return; }
        }
        workoutModel.addElement(w);
    }

    // ======================================================== user actions
    private void sendChat() {
        if (!connected) { info("You are not connected."); return; }
        String text = input.getText().trim();
        if (text.isEmpty()) { Toolkit.getDefaultToolkit().beep(); return; } // blank rejected
        send("CHAT|" + text);
        input.setText("");
    }

    private void proposeDialog() {
        JComboBox<String> activity = new JComboBox<>(new String[]{
                "Running", "Gym - Strength", "Yoga", "Swimming", "Cycling", "Basketball", "Zumba", "Badminton"});
        activity.setEditable(true);
        JTextField when = new JTextField("Today 5:00 PM");
        JTextField where = new JTextField("School gym");
        JPanel panel = new JPanel(new GridLayout(0, 2, 6, 6));
        panel.add(new JLabel("Activity:")); panel.add(activity);
        panel.add(new JLabel("When:"));     panel.add(when);
        panel.add(new JLabel("Where:"));    panel.add(where);
        int r = JOptionPane.showConfirmDialog(this, panel, "Propose a Workout",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (r != JOptionPane.OK_OPTION) return;
        String a = String.valueOf(activity.getSelectedItem()).trim().replace('|', ' ');
        String w = when.getText().trim().replace('|', ' ');
        String l = where.getText().trim().replace('|', ' ');
        if (a.isEmpty() || w.isEmpty() || l.isEmpty()) { info("Activity, time and place are all required."); return; }
        send("PROPOSE|" + a + "|" + w + "|" + l);
    }

    private void rsvp(String status) {
        Workout w = workoutList.getSelectedValue();
        if (w == null) { info("Select a workout session first."); return; }
        send("RSVP|" + w.id + "|" + status);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new FitnessClient().setVisible(true));
    }
}
